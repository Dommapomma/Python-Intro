#-------------------------------------
#  Name:     Presentation1
#  Program:  P1demo.py
# ------------------------------------
# This program converts F to C and predicts tomorrow's temperature.
# Test on:   4 different inputs

# Obtain the temperature for today in Fahrenheit

from datetime import date

today = date.today()

year = today.strftime("%Y")

month = today.strftime("%M")

day = today.strftime("%D")

age = input("What is your age?")

birthday = input("What is your birthday? (mm/dd)")

birthdays = birthday.split("/", -1)

#if(birthdays[0] <)
birth = int(year) - int(age)


print()   # Print a blank line
print("The current date is " + day + ".")
print("Your age is " + str(age) + ".")
print("You were born in " + str(birth) + ".")