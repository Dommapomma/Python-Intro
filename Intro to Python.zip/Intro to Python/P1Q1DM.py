#-------------------------------------
#  Name:     Presentation1
#  Program:  P1demo.py
# ------------------------------------
# This program converts F to C and predicts tomorrow's temperature.
# Test on:   4 different inputs

# Obtain the temperature for today in Fahrenheit

event = input("Special Event:")
adj = input("Adjective:")
person = input("Family Member/Teacher/Friend:")
game = input("Computer Game:")
food = input("Food:")

print()   # Print a blank line
print("Guess what?  Today was " + event)
print("I thought it would be just another " + adj + " class.")
print("But, " + person + " surprised me with a gift.")
print("I always wanted to play " + game + " and now I can!")
print("To celebrate, I had a delicious " + food + "!")